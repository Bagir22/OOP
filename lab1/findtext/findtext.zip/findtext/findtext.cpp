﻿#include <iostream>
#include <fstream>
#include <functional>
#include <string>
#include <optional>


using namespace std;

struct Args
{
    string inputFileName;
    string searchText;
};

using FindStringCallback = function<void(int lineIndex, const string& line, size_t foundPos)>;

bool FindStringInStream(
    istream& text,
    const string& needle,
    const FindStringCallback& callback = FindStringCallback())
{
    string line;
    bool found = false;
    for (int lineIndex = 1; getline(text, line); ++lineIndex)
    {
        auto pos = line.find(needle);
        if (pos != string::npos)
        {
            found = true; 
            if (callback)
            {
                callback(lineIndex, line, pos);
            }
        }
    }
    return found;
}

void PrintFoundLineIndex(int lineIndex, const string& /*line*/, size_t /*foundPos*/)
{
    cout << lineIndex << endl;
}


optional<Args> ParseArgs(int argc, char* argv[])
{
    if (argc != 3)
    {
        cout << "Invalid arguments count\n"
            << "Usage: copyfile.exe <input file> <output file>\n";

        return nullopt;
    }

    Args args;
    args.inputFileName = argv[1];
    args.searchText = argv[2];

    return args;
}

int main(int argc, char* argv[])
{
    auto args = ParseArgs(argc, argv);

    if (!args)
    {
        return 1;
    }

    ifstream input(args->inputFileName);

    if (!input.is_open())
    {
        cout << "Failed to open " << args->inputFileName << " for reading\n";

        return 1;
    }

    if (!FindStringInStream(input, args->searchText, PrintFoundLineIndex))
    {
        cout << "No string found" << endl;
    }

    return 0;
}
